jQuery(document).ready(function() {
	console.log(jQuery('#mydiv').get(0));
});