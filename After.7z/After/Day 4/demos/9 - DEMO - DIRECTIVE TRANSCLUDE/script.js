var app = angular.module('myApp', []);
app.directive('bold', function() {
    return {
      template: '<span ng-transclude style="font-weight:bolder;color:red"></span>',
      restrict: 'EACM',
      replace: true,
      transclude: true,
      link: function($scope, elem) {
        
      }
    };
});

app.controller('Controller', ["$scope",
  function($scope) {

  }
]);