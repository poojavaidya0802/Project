var myApp = angular.module('myApp',[]);

myApp.controller('StudentController', ['$scope', function($scope) {
	$scope.reset = function() {
		$scope.firstName = "Arun";
		$scope.lastName = "James";
		$scope.email = "arunj@cybage.com";
	}
	$scope.reset();
}]);