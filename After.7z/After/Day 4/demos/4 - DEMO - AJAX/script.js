var myApp = angular.module('myApp', []);

myApp.controller('StudentController', ['$scope', '$http',
  function($scope, $http) {
    var url = "data.txt";

    var responsePromise = $http.get(url);

    responsePromise.success(function(response) {
      $scope.students = response;
    });
    responsePromise.error(function(data) {
      alert("AJAX failed!");
    });
    
    //alternate way
    //$http.get(url).success(function(response) {
    //  $scope.students = response;
    //}).error(function(data) {
    //  alert("AJAX failed!");
    //});
  }
]);