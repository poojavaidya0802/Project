function studentController($scope) {
	$scope.student = {
		firstName: "Arun",
		lastName: "James",
		fullName: function() {
			var studentObject;
			studentObject = $scope.student;
			return studentObject.firstName + " " + studentObject.lastName;
		}
	};
}