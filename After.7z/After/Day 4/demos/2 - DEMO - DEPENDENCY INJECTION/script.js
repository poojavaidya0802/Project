var myApp = angular.module("mainApp", []);

myApp.value("numberValue", 8);

myApp.controller("ValueController", function($scope, numberValue) {

  $scope.testNumber = numberValue;

});


//=====================FACTORY====================================

myApp.factory("myFactory", function(numberValue) {
  return "a factory value: " + numberValue;
});

myApp.controller("FactoryController", function($scope, myFactory) {

  $scope.testNumber = myFactory;

});

//=====================SERVICE===================================

function MyService() {
  this.double = function(num) {
    return (num * 2);
  };
}

myApp.service("customService", MyService);


myApp.controller("ServiceController", function($scope, customService, numberValue) {

  $scope.testNumber = customService.double(numberValue);

});


//====================PROVIDER===========================

myApp.provider("ProviderService", function() {
  var provider = {};

  provider.$get = function() {
    var service = {};

    service.doService = function() {
      return "Service called";
    }

    return service;
  }

  return provider;
});


myApp.controller("ProviderController", function($scope, ProviderService) {

  $scope.testNumber = ProviderService.doService();

});


//======================PROVIDER WITH CONFIG=========================


myApp.provider("ProviderConfigService", function() {
  var provider = {};
  var config = {
    configParam: "default"
  };

  provider.doConfig = function(configParam) {
    config.configParam = configParam;
  }


  provider.$get = function() {
    var service = {};

    service.doService = function() {
      return "Service called " + config.configParam;
    }

    return service;
  }

  return provider;
});

myApp.config(function(ProviderConfigServiceProvider) {
  ProviderConfigServiceProvider.doConfig("new config param");
});

myApp.controller("ProviderConfigController", function($scope, ProviderConfigService) {
  $scope.testNumber = ProviderConfigService.doService();

});