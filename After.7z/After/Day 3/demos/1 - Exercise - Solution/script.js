var mainApp = angular.module("mainApp", []);

mainApp.controller("EmployeeList", function($scope) {
	$scope.employees = [{
		"id": 1001,
		"firstName": "Matthew",
		"lastName": "Martinez",
		"email": "k.young@johnson.com",
		"doj": new Date("11/Apr/2011"),
		"ext": "0016"
	}, {
		"id": 1002,
		"firstName": "Frank",
		"lastName": "Perez",
		"email": "a.allen@taylor.com",
		"doj": new Date("15/Jan/2012"),
		"ext": "5834"
	}, {
		"id": 1003,
		"firstName": "Kenneth",
		"lastName": "Johnson",
		"email": "g.harris@williams.com",
		"doj": new Date("02/Dec/2012"),
		"ext": "7558"
	}, {
		"id": 1004,
		"firstName": "Gary",
		"lastName": "Hall",
		"email": "y.thomas@jackson.com",
		"doj": new Date("15/Jan/2012"),
		"ext": "7427"
	}, {
		"id": 1005,
		"firstName": "Donald",
		"lastName": "Martin",
		"email": "dmartin@test.com",
		"doj": new Date("15/Jan/2012"),
		"ext": "2661"
	}, {
		"id": 1006,
		"firstName": "Brian",
		"lastName": "Lee",
		"email": "d.harris@brown.com",
		"doj": new Date("15/Jan/2012"),
		"ext": "1917"
	}];
});