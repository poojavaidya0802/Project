var myApp = angular.module('scopeInheritance', []);

myApp.controller('MainController', ['$scope', '$rootScope', function($scope, $rootScope) {
	$scope.timeOfDay = 'morning';
	$scope.name = 'Nikki';
	$rootScope.msg = 'Helooooooooooooo!';
}]);

myApp.controller('ChildController', ['$scope', function($scope) {
	$scope.timeOfDay = 'afternoon';
	$scope.name = 'Mattie';
}]);

myApp.controller('GrandChildController', ['$scope', function($scope) {
	console.log($scope.$parent.name);
	$scope.timeOfDay = 'evening';
	//$scope.name = 'Gingerbread Baby';
}]);

/************************************************
*	Questions
*		1. Remember the prototype pattern?
*
*		2. What will happen if $scope.name 
*		assignment was commented out in 
*		GrandChildController?
*
*		3. Can I access ChildController scope 
*		from GrandChildController? What is $parent?
*
*		4. What is $rootScope, how to pass it in 
*		and where is it accessible?
**************************************************/