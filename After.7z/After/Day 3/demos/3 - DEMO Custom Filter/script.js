app.controller("DemoController", function($scope) {
	$scope.number=0;
});