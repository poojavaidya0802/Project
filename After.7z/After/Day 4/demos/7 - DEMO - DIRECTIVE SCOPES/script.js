var app = angular.module('myApp', []);

app.controller('CustomersController', ['$scope',
  function($scope) {
    var counter = 0;
    $scope.customer = {
      name: 'Arun',
      street: '1234 Anywhere St.'
    };

    $scope.customers = [{
      name: 'Arun',
      street: '1234 Anywhere St.'
    }, {
      name: 'Shiv',
      street: 'Kalayani Nagar'
    }, {
      name: 'Kunal',
      street: 'Nagar Road'
    }];

    $scope.changeData = function () {
        counter++;
        $scope.customer = {
            name: 'Test',
            street: counter + ' New Address St.'
        };
    };
  }
]);


app.directive('myIsolatedScopeWithName', function() {
  return {
    scope: {
      name: '@'
    },
    template: 'Name: {{ name }}'
  };
});

app.directive('myIsolatedScopeWithName2', function() {
  return {
    scope: {
      customerData: '='
    },
    template: 'Name: {{ customerData.name +", " + customerData.street }}'
  };
});

app.directive('myIsolatedScopeWithModel3', function () {
    return {
        scope: {
            datasource: '=',
            action: '&'
        },
        template: '<button ng-click="action()">Change Data</button>'
    };
});




