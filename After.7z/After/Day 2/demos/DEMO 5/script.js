function Controller($scope) {
	$scope.oldNames = [];
	$scope.name = "Arun";
	$scope.$watch('name', function(newVal, oldVal) {
		$scope.oldNames.push({from: oldVal, to: newVal});
	});
}