var myApp = angular.module('myApp', []);

myApp.controller('StudentController', ['$scope', '$q', '$timeout',
  function($scope, $q, $timeout) {
    function deferredTimer(success, seconds) {
      var deferred = $q.defer();

      $timeout(function() {
        if (success) {
          deferred.resolve({
            message: "This is great!"
          });
        } else {
          deferred.reject({
            message: "Really bad"
          });
        }
      }, seconds * 1000);

      return deferred.promise;
    }


    $scope.showMessage1 = function(success) {
      deferredTimer(success, 2).then(function(data) {
        $scope.message1 = data;
      },function(data){
        $scope.errorMsg=data.message;
      });
    };
    
    $scope.showMessage2 = function(success) {
      deferredTimer(success, 4).then(function(data) {
        $scope.message2 = data;
      });
    };
    
    $scope.showMessage1(true);
    $scope.showMessage2(true);
     $scope.showMessage1(false);
  }
]);