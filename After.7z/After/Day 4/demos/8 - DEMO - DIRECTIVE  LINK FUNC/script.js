var app = angular.module('myApp', []);

app.directive('changeColor', function() {
  return {
    restrict: 'E',
    replace: true,
    template: '<p style="background-color:{{color}}">Hello World</p>',
    link: function(scope, elem, attrs) {
      elem.bind('click', function() {
        elem.css('background-color', 'white');
        scope.$apply(function() {
          scope.color = "white";
        });
      });
      elem.bind('mouseover', function() {
        elem.css('cursor', 'pointer');
      });
    }
  };
});

app.controller('Controller', ["$scope",
  function($scope) {
    $scope.greetings = "Hello";
    $scope.to = "World";
  }
]);