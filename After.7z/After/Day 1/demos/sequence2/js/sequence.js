require(['jquery'], function(jQuery) {
	jQuery(document).ready(function() {
		console.log(jQuery('#mydiv').get(0));
	});
});