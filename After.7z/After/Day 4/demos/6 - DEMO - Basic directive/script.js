var app = angular.module('myApp', []);
app.directive('helloWorld', function() {
    return {
        template: '<h1>{{greetings}} {{to}}</h1>',
        restrict: 'EACM', //E = element, A = attribute, C = class, M = comment 
        replace: true,
    }
});

app.controller('Controller', ["$scope", function($scope) {
    $scope.greetings = "Hello";
    $scope.to = "World";
}]);