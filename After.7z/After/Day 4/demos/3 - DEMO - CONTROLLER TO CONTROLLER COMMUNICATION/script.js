

mainApp.controller("Controller1", function($scope, sharedService) {
    $scope.message=sharedService.getMessage();
    sharedService.editMessage("changed from controller 1")
});

mainApp.controller("Controller2", function($scope, sharedService) {
    $scope.message=sharedService.getMessage();
});