 mainApp.controller('AddStudentController', function($scope) {
      $scope.message = "This page will be used to display add student form";
    });
    mainApp.controller('ViewStudentsController', function($scope) {
      $scope.message = "This page will be used to display all the students";
    });