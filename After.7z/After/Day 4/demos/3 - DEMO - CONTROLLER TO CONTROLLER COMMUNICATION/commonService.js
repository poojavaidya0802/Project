function SharedService() {
  var message="shared service call";
    this.editMessage = function(newMsg) {
       message=newMsg;
    }
    
    this.getMessage = function(newMsg) {
       return message;
    }
}

mainApp.service("sharedService", SharedService);